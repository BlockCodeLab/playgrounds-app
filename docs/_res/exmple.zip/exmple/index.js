export default {
  icon: "./icon.png",
  name: "积木案例",
  blocks,
};

// 图形积木定义列表
function blocks(metadata) {
  return [
    {
      id: "command",
      text: "引脚值[Pin] 菜单值[Option]",
      inputs: {
        Pin: {
          menu: metadata.boardPins.out,
        },
        Option: {
          menu: [
            ["高", "1"],
            ["低", "0"],
          ],
        },
      },
      ino(_, args) {
        return `digitalWrite(${args.Pin}, ${args.Option});`;
      },
      mpy(_, args) {
        return `Pin(${args.Pin}, Pin.OUT).value = ${args.Option}`;
      },
    },
    "---",
    {
      id: "numberOrString",
      text: "输出[Value]",
      output: "string",
      inputs: {
        Value: {
          type: "string",
          defaultValue: "hi",
        },
      },
      ino(_, args) {
        return [args.Value];
      },
      mpy(_, args) {
        return [args.Value];
      },
    },
    {
      id: "boolean",
      text: "输出布尔值",
      output: "boolean",
      ino(_, args) {
        return ["false"];
      },
      mpy(_, args) {
        return ["False"];
      },
    },
    "---",
    { label: "各种参数输入" },
    {
      id: "integer",
      text: "整数类型参数 [Num]",
      inputs: {
        Num: {
          type: "integer",
          defaultValue: -1,
        },
      },
      ino(_, args) {
        return args.Num;
      },
      mpy(_, args) {
        return args.Num;
      },
    },
    {
      id: "positive",
      text: "正数类型参数 [Num]",
      inputs: {
        Num: {
          type: "positive",
          defaultValue: 1.1,
        },
      },
      ino(_, args) {
        return args.Num;
      },
      mpy(_, args) {
        return args.Num;
      },
    },
    {
      id: "positiveInteger",
      text: "正整数类型参数 [Num]",
      inputs: {
        Num: {
          type: "positive_integer",
          defaultValue: 2,
        },
      },
      ino(_, args) {
        return args.Num;
      },
      mpy(_, args) {
        return args.Num;
      },
    },
    {
      id: "angle",
      text: "角度参数 [Angle]",
      inputs: {
        Angle: {
          type: "angle",
          defaultValue: 90,
        },
      },
      ino(_, args) {
        return args.Angle;
      },
      mpy(_, args) {
        return args.Angle;
      },
    },
    {
      id: "color",
      text: "颜色参数 [Color]",
      inputs: {
        Color: {
          type: "color",
        },
      },
      ino(_, args) {
        return args.Color;
      },
      mpy(_, args) {
        return args.Color;
      },
    },
    {
      id: "matrix",
      text: "颜色参数 [Matrix]",
      inputs: {
        Matrix: {
          type: "matrix",
          defaultValue: "0000001010000000101000000",
        },
      },
      ino(_, args) {
        return args.Matrix;
      },
      mpy(_, args) {
        return args.Matrix;
      },
    },
    {
      id: "note",
      text: "音符参数 [Note]",
      inputs: {
        Note: {
          type: "note",
          defaultValue: "c4",
        },
      },
      ino(_, args) {
        return args.Note;
      },
      mpy(_, args) {
        return args.Note;
      },
    },
  ];
}
