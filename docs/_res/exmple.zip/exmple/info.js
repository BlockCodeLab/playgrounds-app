export default {
  image: "./feature.png",
  icon: "./icon.png",
  name: "积木案例",
  description: "展示各种类型积木案例",
  tags: ["device", "arduino"],
};
