#pragma once

#ifndef _EM_PM25_SENSOR_H_
#define _EM_PM25_SENSOR_H_

#include <Arduino.h>
#include <Wire.h>

namespace em {

class Pm25Sensor {
public:
  Pm25Sensor(const uint8_t iled_pin, const uint8_t dust_pin);
  void Init();
  float Read() const;

private:
  Pm25Sensor(const Pm25Sensor &) = delete;
  Pm25Sensor &operator=(const Pm25Sensor &) = delete;

  uint16_t Filter(const uint16_t adc_value) const;

  uint8_t iled_pin_ = 0;
  uint8_t dust_pin_ = 0;
};

} // namespace em
#endif
