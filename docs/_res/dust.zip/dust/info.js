export default {
  // 版本
  version: "1.0.0",
  // 主题图，相对路径
  image: "./feature.png",
  // 图标，相对路径
  icon: "./icon.png",
  // 扩展名
  name: "粉尘检测",
  // 扩展描述
  description: "PM2.5 颗粒检测传感器。",
  // 合作者/作者
  collaborator: "Emakefun",
  // 扩展过滤标签
  tags: [
    "arduino", // Arduino 系列开发板可用
    "sensor", // 分类标签：传感器
  ],
  // 信息外链
  readme:
    "https://docs.emakefun.com/#/zh-cn/ph2.0_sensors/sensors/pm2.5_dust_sensor/pm2.5_dust_sensor",
};
