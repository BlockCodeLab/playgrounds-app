export default {
  // 主题图，相对路径
  image: "./feature.png",
  // 图标，相对路径
  icon: "./icon.png",
  // 扩展名
  name: "微尘检测",
  // 扩展描述
  description: "PM2.5 颗粒检测传感器。",
  // 扩展过滤标签
  tags: [
    "arduino", // Arduino 系列开发板可用
    "sensor", // 分类标签：传感器
  ],
};
