// 积木配置
export default {
  // 图标，相对路径
  icon: "./icon.png",
  // 积木主体颜色
  // themeColor: "#0fbd8c",
  // 积木边框颜色
  // otherColor: "#0b8e69",
  // 扩展名
  name: "粉尘检测",
  // 图形积木定义列表
  blocks,
  // 转换代码库文件列表
  files,
};

// 图形积木定义列表
// metadata：编辑器元数据，可以获取档案主板引脚信息以及编辑器信息，用于扩展适配不同的编辑器或主板
function blocks(metadata) {
  return [
    {
      // 积木 ID，扩展内的每个积木 ID 必须唯一
      id: "pm25value",
      // 积木的文本描述，[ARG] 是输入参数的占位符，ARG 是参数名
      text: "引脚 D:[DPin] A:[APin] 的 PM2.5 浓度（μg/m³）",
      // 积木为输出样式（两头为圆或尖角），输出类型积木
      // 可选类型：number, string, boolean
      output: "number",
      // 输入参数列表
      inputs: {
        // 文本描述中占位符 [DPin] 的参数名
        DPin: {
          // 选项菜单：开发板输出引脚的下拉选项
          menu: metadata.boardPins.out,
        },
        // [APin] 参数名
        APin: {
          // 选项菜单：主板的 ADC 引脚
          menu: metadata.boardPins.adc,
        },
      },
      // Arduino 代码转换函数
      // block：当前积木
      // args：输入的参数列表，用的文本描述中占位符的参数名作为 key
      // defs：代码头（初始代码）定义
      ino(block, args, defs) {
        // 代码头定义：引用库文件，文件列表中该文件以设为自动引用，可不用再添加
        // defs[`include_pm25_sensor`] = `#include "pm25_sensor.h"`;
        // 代码头定义：定义全局变量
        defs[`variable_pm25`] = `em::Pm25Sensor pm25(${args.DPin}, ${args.APin});`;
        // 代码头定义：setup 前置代码（保持在 setup 内最前面的代码）
        defs[`setup_pm25_init`] = `pm25.Init();`;
        // 代码头定义：loop 前置代码（保持在 loop 内最前面的代码）
        // defs[`loop_...`] = `...`;
        // 积木转换的实际工作代码
        const code = `pm25.Read()`;
        return [code]; // 输出类型的积木，返回的转换代码必须是 [code] 数组形式
      },
      // MicroPython 代码转换函数
      // mpy(block, args) {}, // 暂不转换代码时空缺，或直接返回空字符串，否则会报错
    },
  ];
}

// 转换代码库文件列表
function files(metadata) {
  return metadata.isArduino
    ? [
        // PM2.5 传感器 Arudino 库文件
        {
          // 自动引用该文件
          header: true,
          // 保存文件名
          name: "pm25_sensor.h",
          // 文件位置，相对路径
          uri: "./lib/pm25_sensor.h",
        },
        {
          name: "pm25_sensor.cpp",
          uri: "./lib/pm25_sensor.cpp",
        },
      ]
    : [
        // PM2.5 传感器 MicroPython 库文件
        // 没有直接返回空数组
      ];
}
